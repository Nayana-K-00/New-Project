from django.contrib import admin
from home.models import Contact, Newsletter, CVerify

# Register your models here.
admin.site.register(Contact)
admin.site.register(Newsletter)
admin.site.register(CVerify)
