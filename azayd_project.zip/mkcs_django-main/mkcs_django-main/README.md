# Azayd IT  Consulting Services Dev Website [![forthebadge](https://forthebadge.com/images/badges/made-with-python.svg)](https://forthebadge.com) [![forthebadge](https://forthebadge.com/images/badges/uses-html.svg)](https://forthebadge.com)  [![forthebadge](https://forthebadge.com/images/badges/uses-css.svg)](https://forthebadge.com) [![forthebadge](https://forthebadge.com/images/badges/uses-js.svg)](https://forthebadge.com)  <img alt="Django" src="https://img.shields.io/badge/django-%23092E20.svg?&style=for-the-badge&logo=django&logoColor=white"/>  <img alt="SQLite" src ="https://img.shields.io/badge/SQLite-07405E?style=for-the-badge&logo=sqlite&logoColor=white"/>

**This is a Dev Website of the original [Azayd IT Consulting Services](https://www.azaydconsultingservices.com/) website.**

_This website was made using Python Django Framework, Tailwind CSS and few APIs such as Tawk Live Chat API, Venobox API and Google Tag Manager API._

> ### Some of the Django features are showcased

* Template Inheritance
* Creating REST APIs

---
> ### Django MVT Architecture
![image](https://www.javatpoint.com/django/images/django-mvt-based-control-flow.png)




### ThankYou!
